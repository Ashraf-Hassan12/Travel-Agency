import { Component, AfterViewInit } from '@angular/core';

@Component({
  selector: '[app-banner]',
  templateUrl: './app-banner.component.html',
})
export class AppBanner implements AfterViewInit {

  constructor(
  ) { }

  ngAfterViewInit()  {
	}

}
